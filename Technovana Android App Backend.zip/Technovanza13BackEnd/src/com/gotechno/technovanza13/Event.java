package com.gotechno.technovanza13;

public class Event {
	String time, name, room;
	int color;
	Event(String time, String name, String room, int color){
		this.time=time;
		this.name=name;
		this.room=room;
		this.color=color;
	}
}
