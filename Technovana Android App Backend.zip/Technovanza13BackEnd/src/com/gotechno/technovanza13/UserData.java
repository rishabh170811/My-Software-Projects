package com.gotechno.technovanza13;

import java.io.Serializable;

public class UserData implements Serializable{
	public String name,gender,SHAHash,cellNo,collegeName,branchName,email,location,technoID;
}
