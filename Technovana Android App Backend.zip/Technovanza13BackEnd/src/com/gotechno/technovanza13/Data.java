package com.gotechno.technovanza13;

public class Data {
	public static String nick;
	public static final String userDataFileName="UserData.ser";
	public static final String firstUseFileName="FirstUseFile";
	public static boolean showRegistrationMenu;
}
