import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;

import oracle.spatial.geometry.JGeometry;

public class DisplaySpatial extends JFrame implements ActionListener{

	//HW2 hw2 = new HW2();
	Connection mainConnection = null;
	private JPanel contentPane;
	JPanel panel;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	JRadioButton rdbtnWholeRegion;
	JRadioButton rdbtnPointQuery;
	JRadioButton rdbtnRangeQuery;
	JRadioButton rdbtnSurroundingStudent;
	JRadioButton rdbtnEmergencyQuery;
	JCheckBox chkboxAs;
	JCheckBox chkboxBuildings;
	JCheckBox chkboxLion;
	JTextArea displayQuery;
	JScrollPane scrollPane;
	JTextField mouseLocation;
	ArrayList<Point> userPointInput = new ArrayList<Point>() ;
	String[] ASid = new String[10];
	static int queryCount = 0;
	boolean rightClick = false;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
                               
                                    
		
            EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
                                            
					DisplaySpatial frame = new DisplaySpatial();
					frame.ConnectToDB();
					frame.setTitle("Rishabh Sharma-7628846249");
					frame.setVisible(true);
                                        
                                } catch (Exception e) {
					System.out.println(e.getMessage());
				}
			}
                        
                });
	}

	/**
	 * Create the frame.
	 */
	public DisplaySpatial() {
                int Xcoor,Ycoor;
                                    
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(0, 0,screen.width - 300,screen.height - 70);
		contentPane = new JPanel();
		//contentPane = new JFrame();
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		//contentPane.set
		setContentPane(contentPane);		
		//panel = new JPanel();
		panel = new paintPanel();
		javax.swing.GroupLayout imagePanelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(imagePanelLayout);
        imagePanelLayout.setHorizontalGroup(imagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 820, Short.MAX_VALUE));
        imagePanelLayout.setVerticalGroup(imagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 580, Short.MAX_VALUE));
        
		panel.setBounds(0, 0, 820, 580);
        contentPane.setLayout(null);
        contentPane.setLayout(null);
		contentPane.add(panel);
		
		panel.addMouseListener(new java.awt.event.MouseAdapter() {
                
                    
        });
		
		displayQuery = new JTextArea();
		//displayQuery.setBounds(5, 606, 1035, 28);
		displayQuery.setColumns(20);
		displayQuery.setRows(10);
		displayQuery.setWrapStyleWord(true);
		contentPane.add(displayQuery);
		//scrollPane = new JScrollPane(displayQuery);
		scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 590, 1035, 60);
		displayQuery.setRows(5);
		displayQuery.setEditable(false);
		scrollPane.getViewport().setView(displayQuery);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		contentPane.add(scrollPane);
		
		JLabel label1 = new JLabel("Spatial GUI");
		label1.setFont(new Font("Arial", Font.BOLD, 18));
		label1.setHorizontalAlignment(SwingConstants.CENTER);
		label1.setBounds(847, 31, 193, 35);
		contentPane.add(label1);
		
		chkboxAs = new JCheckBox("select_lion_pond_in_region");
		chkboxAs.setFont(new Font("Arial", Font.PLAIN, 50));
		chkboxAs.setHorizontalAlignment(SwingConstants.LEFT);
		chkboxAs.setBounds(864, 85, 48, 23);
		contentPane.add(chkboxAs);
		
		
		mouseLocation = new JTextField();
		panel.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				int Xcoor = e.getX();
                                    int Ycoor = e.getY();    
                             if(chkboxAs.isSelected())
                            {
                                    try {
                                        displayRedLion(Xcoor, Ycoor);
                                        displayRedPond(Xcoor,Ycoor);
                                    } catch (SQLException ex) {
                                        Logger.getLogger(DisplaySpatial.class.getName()).log(Level.SEVERE, null, ex);
                                    }
			}
                        }
		});
		mouseLocation.setBounds(882, 434, 100, 35);
		contentPane.add(mouseLocation);
		
		JButton SubmitQueryButton = new JButton("Submit Query");
		SubmitQueryButton.addActionListener(this);
		SubmitQueryButton.setFont(new Font("Arial", Font.PLAIN, 15));
		SubmitQueryButton.setBounds(852, 494, 167, 35);
		contentPane.add(SubmitQueryButton);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
                
                                    displayRegions();
                                       displayPond();
                                        
                                       displayLion();
		
            			
		}

public void displayRedPond(int X,int Y) throws SQLException{
        Statement stmt=null;
        displayPond();
	int radius;
       String sql = "select polygon from pond pp where pp.pond_id in(SELECT pond_id FROM pond p,Regions r  WHERE sdo_relate(p.polygon,r.polygon,'mask = ANYINTERACT') = 'TRUE'  and id in (select id from regions r1 where sdo_relate(r1.polygon,SDO_geometry(1,NULL,NULL,SDO_elem_info_array(1,1,1),SDO_ordinate_array("+X+","+Y+")),'mask=ANYINTERACT'   ) = 'TRUE' ))";
        queryCount++; 
            if(queryCount != 1)
		displayQuery.append("\n");
		displayQuery.append("Query " + queryCount + ": " + sql);
		try
		{
			stmt = mainConnection.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
                            double[] points;
				oracle.sql.STRUCT struct = (oracle.sql.STRUCT) rs.getObject("polygon");
				JGeometry jgeom = JGeometry.load(struct);
				//Point2D point = jgeom.getJavaPoint();
                             int x[] = new int[10];
                             int y[] = new int[10];
                            
                                points = jgeom.getOrdinatesArray();
				for(int i = 0; i < points.length; i++)
				{
					if((i % 2) == 0)
					{
						x[i]=(int)points[i];
					}
					else
					{
						y[i]=(int)points[i];
					}
                                        
				}
				radius = (y[5]-y[1])/2;
                 
				//draw the point
				//paintPanel.drawPond(panel.getGraphics(), x[0], y[3], Color.RED);
				//draw the circle
				paintPanel.drawPondRange(panel.getGraphics(), x[0], y[3], radius, Color.RED);
        }
                }
                catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
        }

	public void displayRedLion(int X,int Y) throws SQLException{
               Statement stmt=null;
               displayLion();
               int x,y;
            String sql ="SELECT Lion.shape from Lion,Regions b where SDO_RELATE(b.POLYGON,SDO_GEOMETRY(1,NULL,NULL,SDO_ELEM_INFO_ARRAY(1,1,1),SDO_ORDINATE_ARRAY("+""+X+""+","+Y+")),'mask=ANYINTERACT')='TRUE'AND LION_ID IN (SELECT Lion_ID FROM Lion where SDO_RELATE(b.POLYGON,Lion.shape,'mask=ANYINTERACT')='TRUE')";
		queryCount ++;
		if(queryCount != 1)
			displayQuery.append("\n");
		displayQuery.append("Query " + queryCount + ": " + sql);
		try
		{
			stmt = mainConnection.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
                            oracle.sql.STRUCT struct = (oracle.sql.STRUCT) rs.getObject("shape");
				JGeometry jgeom = JGeometry.load(struct);
				Point2D point = jgeom.getJavaPoint();
				x = (int) point.getX();
				y = (int) point.getY();
				//draw the point
				paintPanel.drawLion(panel.getGraphics(), x, y, Color.RED);
                        }
                }
                catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
        }
	public void displayLion()
	{
		Statement stmt = null;
		int x;
		int y;
		String sql = "SELECT s.shape from Lion s";
		queryCount ++;
		if(queryCount != 1)
			displayQuery.append("\n");
		displayQuery.append("Query " + queryCount + ": " + sql);
		try
		{
			stmt = mainConnection.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				oracle.sql.STRUCT struct = (oracle.sql.STRUCT) rs.getObject("shape");
				JGeometry jgeom = JGeometry.load(struct);
				Point2D point = jgeom.getJavaPoint();
				x = (int) point.getX();
				y = (int) point.getY();
				//draw the point
				paintPanel.drawLion(panel.getGraphics(), x, y, Color.GREEN);
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
	}
	
	public void displayPond()
	{
        	Statement stmt = null;
		int radius;

                String sql = "SELECT a.polygon from Pond a";
		queryCount ++;
		if(queryCount != 1)
			displayQuery.append("\n");
		displayQuery.append("Query " + queryCount + ": " + sql);
		try
		{
			stmt = mainConnection.createStatement();
			
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
                            double[] points;
				oracle.sql.STRUCT struct = (oracle.sql.STRUCT) rs.getObject("polygon");
				JGeometry jgeom = JGeometry.load(struct);
				//Point2D point = jgeom.getJavaPoint();
                             int x[] = new int[10];
                             int y[] = new int[10];
                            
                                points = jgeom.getOrdinatesArray();
				for(int i = 0; i < points.length; i++)
				{
					if((i % 2) == 0)
					{
						x[i]=(int)points[i];
					}
					else
					{
						y[i]=(int)points[i];
					}
                                        
				}
				radius = (y[5]-y[1])/2;
                 
				//draw the point
				//paintPanel.drawPond(panel.getGraphics(), x[0], y[3], Color.RED);
				//draw the circle
				paintPanel.drawPondRange(panel.getGraphics(), x[0], y[3], radius, Color.BLUE);
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

    public void displayRegions()
	{
Statement stmt = null;
ArrayList<Integer> x = new ArrayList<Integer>();
ArrayList<Integer> y = new ArrayList<Integer>();
		double[] points;
		String sql = "SELECT b.POLYGON from Regions b";
		queryCount ++;
		if(queryCount != 1)
			displayQuery.append("\n");
		displayQuery.append("Query " + queryCount + ": " + sql);
		try
		{
			stmt = mainConnection.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				x.clear();
				y.clear();
				oracle.sql.STRUCT struct = (oracle.sql.STRUCT)rs.getObject("POLYGON");
				JGeometry jgeom = JGeometry.load(struct);
				points = jgeom.getOrdinatesArray();
				for(int i = 0; i < points.length; i++)
				{
					if((i % 2) == 0)
					{
						x.add((int)points[i]);
					}
					else
					{
						y.add((int)points[i]);
					}
				}
				paintPanel.drawBoundaries(panel.getGraphics(), x, y, x.size(), Color.BLACK);
                               
                        }
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	
	public void ConnectToDB()
 	{
		try
		{
			// loading Oracle Driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
	    	DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
	    	//System.out.println(", Loaded.");

	    	String URL = "jdbc:oracle:thin:@localhost:1521:xe";
	    	String userName = "SYSTEM";
	    	String password = "mambas";

	    	//System.out.print("Connecting to DB...");
	    	mainConnection = DriverManager.getConnection(URL, userName, password);
	    	//System.out.println(", Connected!");

    		//mainStatement = mainConnection.createStatement();

   		}
   		catch (Exception e)
   		{
     		System.out.println( "Error while connecting to DB: "+ e.toString() );
     		System.out.println(e.getMessage());
     		System.exit(-1);
   		}
 	}

}

class paintPanel extends JPanel
{
	private static BufferedImage map;
	
	public static void drawBoundaries(Graphics g, ArrayList<Integer> x, ArrayList<Integer> y, int verticesCount, Color c)
	{
                
                
                int[] coordinateX = new int[verticesCount];
		int[] coordinateY = new int[verticesCount];
		for(int i = 0; i < verticesCount; i++)
		{
			coordinateX[i] = x.get(i).intValue();
			coordinateY[i] = y.get(i).intValue();
		}
                g.setColor(Color.WHITE);
                g.fillPolygon(coordinateX, coordinateY, verticesCount);
		g.setColor(c);
		g.drawPolygon(coordinateX, coordinateY, verticesCount);
                		
        }
	public static void HighdrawLion(Graphics g, int x, int y, Color c)
	{
		g.setColor(Color.RED);
		g.fillRect(x - 5, y - 5, 10, 10);
        }
	public static void highASRange(Graphics g, int x, int y, int radius, Color c) {
		g.setColor(Color.RED);
		g.fillOval(x - radius, y - radius, 2 * radius, 2 * radius);
		g.setColor(c);
		g.drawOval(x - radius, y - radius, 2 * radius, 2 * radius);

	}
	public static void drawLion(Graphics g, int x, int y, Color c)
	{
		g.setColor(c);
		g.fillRect(x - 5, y - 5, 10, 10);
	}

	public static void drawPond(Graphics g, int x, int y, Color c)
	{
		
                g.setColor(c);
		g.fillRect(x, y, 15, 15);
                
        }
	
	public static void drawPondRange(Graphics g, int x, int y, int radius, Color c)
	{
                              
                g.setColor(c);
                g.fillOval(x-radius, y-radius, 2*radius,2*radius);
                g.setColor(Color.BLACK);
                g.drawOval(x - radius, y - radius, 2 * radius, 2 * radius);
                
        }
	
	public static void drawUserPoint(Graphics g, Point p)
	{
		g.setColor(Color.RED);
		g.fillRect((int) p.getX(), (int) p.getY(), 5, 5);
		g.drawOval((int) p.getX() - 50, (int) p.getY() - 50, 2*50, 2*50);
	}
	
	public static void drawLine(Graphics g, Point p1, Point p2)
	{
		g.setColor(Color.RED);
		g.drawLine((int) p1.getX(), (int) p1.getY(), (int) p2.getX(), (int) p2.getY());
	}
	
	public paintPanel() 
	{
        try 
        {
        	//map = ImageIO.read(getClass().getResource("map.jpg"));
        	map = ImageIO.read(new File("map.jpg"));
        } catch (IOException e) {
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(map, 0, 0, null);

    }
   
	public static void clearImage(Graphics g)
	{
		g.drawImage(map, 0, 0, null);
	}
}